<?php

class Conn {
public static $dbhost = "localhost";
public static $dbuser = "root";
public static $dbpass = "Cryptex1990";
public static $dbname = "SwiftApp";
}

?>